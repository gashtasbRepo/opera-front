const Analyze = () => {
  return (
    <div>Analyze</div>
  )
}

export default Analyze