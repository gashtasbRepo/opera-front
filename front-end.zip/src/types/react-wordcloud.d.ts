declare module 'react-wordcloud' {
    const ReactWordCloud: any;
    export default ReactWordCloud;
}
